/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : db_perpus

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2022-06-24 13:01:39
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `anggota`
-- ----------------------------
DROP TABLE IF EXISTS `anggota`;
CREATE TABLE `anggota` (
  `id_anggota` varchar(10) NOT NULL,
  `nama_anggota` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  PRIMARY KEY (`id_anggota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of anggota
-- ----------------------------
INSERT INTO `anggota` VALUES ('LBM001', 'Villen', 'Laki-laki', 'Bandung', '082xxxxxxxxx');
INSERT INTO `anggota` VALUES ('LBM002', 'Vanny', 'Perempuan', 'Kuningan', '0852xxxxxxx');
INSERT INTO `anggota` VALUES ('LBM003', 'Asep', 'Laki-laki', 'Ambon', '0812xxxxxxxx');
INSERT INTO `anggota` VALUES ('LBM004', 'Fauzan', 'Laki-laki', 'Bandung', '2108067');
INSERT INTO `anggota` VALUES ('LBM005', 'Naufal', 'Laki-laki', 'Bandung', '2105673');
INSERT INTO `anggota` VALUES ('LBM006', 'Cantika', 'Perempuan', 'Bandung', '2103727');
INSERT INTO `anggota` VALUES ('LBM007', 'Anan', 'Perempuan', 'Bandung', '2101114');

-- ----------------------------
-- Table structure for `author`
-- ----------------------------
DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `id_pengarang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengarang` varchar(50) NOT NULL,
  PRIMARY KEY (`id_pengarang`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of author
-- ----------------------------
INSERT INTO `author` VALUES ('1', 'Nathan');
INSERT INTO `author` VALUES ('3', 'Aurel');
INSERT INTO `author` VALUES ('4', 'Bintang');
INSERT INTO `author` VALUES ('5', 'Rifqi');
INSERT INTO `author` VALUES ('6', 'Khana');

-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `id_buku` varchar(10) NOT NULL,
  `id_pengarang` int(11) NOT NULL,
  `id_penerbit` int(11) NOT NULL,
  `judul_buku` varchar(50) NOT NULL,
  `tahun_terbit` int(10) NOT NULL,
  `jumlah` int(10) NOT NULL,
  PRIMARY KEY (`id_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('3', '1', '1', '3', '2000', '3');
INSERT INTO `book` VALUES ('abc', '4', '1', 'abc', '1945', '0');
INSERT INTO `book` VALUES ('asd', '6', '3', 'asd', '1951', '2');
INSERT INTO `book` VALUES ('BCTEst', '5', '4', 'test 2', '1948', '1');
INSERT INTO `book` VALUES ('DWP001', '3', '3', 'Design Web Pemrograman I', '2000', '5');
INSERT INTO `book` VALUES ('HP3', '4', '5', 'Harry Potter', '2001', '99');
INSERT INTO `book` VALUES ('SB1', '6', '6', 'Spongebob', '2008', '4');

-- ----------------------------
-- Table structure for `login`
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of login
-- ----------------------------
INSERT INTO `login` VALUES ('1', 'Admin', 'admin', 'admin', 'Administrator');
INSERT INTO `login` VALUES ('2', 'Villen', 'villen', 'villen', 'Petugas');

-- ----------------------------
-- Table structure for `peminjaman`
-- ----------------------------
DROP TABLE IF EXISTS `peminjaman`;
CREATE TABLE `peminjaman` (
  `id_pm` varchar(10) NOT NULL,
  `id_anggota` varchar(10) NOT NULL,
  `id_buku` varchar(10) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  PRIMARY KEY (`id_pm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of peminjaman
-- ----------------------------
INSERT INTO `peminjaman` VALUES ('BB001', 'LBM001', 'DWP001', '2022-02-01', '2022-02-07');
INSERT INTO `peminjaman` VALUES ('BB002', 'LBM002', 'DWP001', '2022-05-13', '2022-05-20');
INSERT INTO `peminjaman` VALUES ('BB003', 'LBM003', 'DWP001', '2022-06-08', '2022-06-15');
INSERT INTO `peminjaman` VALUES ('BB004', 'LBM007', 'HP3', '2022-06-09', '2022-06-16');
INSERT INTO `peminjaman` VALUES ('BB005', 'LBM006', 'DWP001', '2022-06-16', '2022-06-23');

-- ----------------------------
-- Table structure for `pengembalian`
-- ----------------------------
DROP TABLE IF EXISTS `pengembalian`;
CREATE TABLE `pengembalian` (
  `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT,
  `id_anggota` varchar(20) NOT NULL,
  `id_buku` varchar(20) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `tgl_return` date NOT NULL,
  PRIMARY KEY (`id_pengembalian`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of pengembalian
-- ----------------------------
INSERT INTO `pengembalian` VALUES ('1', 'LBM001', 'DWP001', '2022-06-15', '2022-06-22', '2022-06-15');
INSERT INTO `pengembalian` VALUES ('2', 'LBM001', 'DWP001', '2022-06-15', '2022-06-22', '2022-06-15');
INSERT INTO `pengembalian` VALUES ('3', 'LBM002', 'DWP001', '2022-06-15', '2022-06-22', '2022-06-15');
INSERT INTO `pengembalian` VALUES ('4', 'LBM003', 'test', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('5', 'LBM004', 'DWP001', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('6', 'LBM004', 'DWP001', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('7', 'LBM001', 'SB1', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('8', 'LBM002', 'SB2', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('9', 'LBM001', 'BCTEst', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('10', 'LBM001', 'BCTEst', '2022-06-16', '2022-06-23', '2022-06-16');
INSERT INTO `pengembalian` VALUES ('11', 'LBM001', 'abc', '2022-06-23', '2022-06-30', '2022-06-23');
INSERT INTO `pengembalian` VALUES ('12', 'LBM001', 'abc', '2022-06-24', '2022-07-01', '2022-06-24');

-- ----------------------------
-- Table structure for `publisher`
-- ----------------------------
DROP TABLE IF EXISTS `publisher`;
CREATE TABLE `publisher` (
  `id_penerbit` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penerbit` varchar(50) NOT NULL,
  PRIMARY KEY (`id_penerbit`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of publisher
-- ----------------------------
INSERT INTO `publisher` VALUES ('1', 'publisher 1');
INSERT INTO `publisher` VALUES ('3', 'publish2');
INSERT INTO `publisher` VALUES ('4', 'Hilmi');
INSERT INTO `publisher` VALUES ('5', 'Fahru');
INSERT INTO `publisher` VALUES ('6', 'Rafi');
DELIMITER ;;
CREATE TRIGGER `jml_after_pinjam` AFTER INSERT ON `peminjaman` FOR EACH ROW UPDATE book SET book.jumlah = book.jumlah -1 WHERE book.id_buku = new.id_buku
;;
DELIMITER ;
DELIMITER ;;
CREATE TRIGGER `jml_after_return` AFTER INSERT ON `pengembalian` FOR EACH ROW UPDATE book SET book.jumlah = book.jumlah +1 WHERE book.id_buku = new.id_buku
;;
DELIMITER ;
