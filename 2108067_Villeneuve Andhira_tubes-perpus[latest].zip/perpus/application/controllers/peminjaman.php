<?php

class Peminjaman extends CI_Controller {

    //memanggil model
    public function __construct(){
        parent::__construct();
        $this->load->model('m_peminjaman');
    }

    //menampilkan view
    public function index() {
        //ambil data
        $isi['data']    = $this->m_peminjaman->getDataPeminjaman();
        $this->load->view('peminjaman/v_peminjaman', $isi);
    }

    //menambahkan data
    public function add_borrow() {
        $isi['id_peminjaman']   = $this->m_peminjaman->id_peminjaman();
        $isi['peminjam']        = $this->db->get('anggota')->result();
        $isi['book']            = $this->db->get('book')->result();
        $this->load->view('peminjaman/t_peminjaman', $isi);
    }

    //menyimpan data ke dalam database
    public function save() {
        //isi data
        $data = array(
            'id_pm'         => $this->input->post('id_pm'),
            'id_anggota'    => $this->input->post('id_anggota'),
            'id_buku'       => $this->input->post('id_buku'),
            'tgl_pinjam'    => $this->input->post('tgl_pinjam'),
            'tgl_kembali'   => $this->input->post('tgl_kembali'),
        );
        //query insert ke tabel 'peminjaman'
        $query = $this->db->insert('peminjaman', $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Successful transaction');
            redirect('peminjaman');
        }
    }

    // //menghitung jumlah stok buku
    // public function jumlah_buku() {
    //     $id = $this->input->post('id');
    //     $data = $this->m_peminjaman->jumlah_buku($id);
    //     //menyandikan nilai
    //     echo json_encode($data);
    // }

    //mengembalikan buku
    public function returnBook($id) {
        //id
        $data = $this->m_peminjaman->getDataById_pm($id);
        //isi data
        $returned = array(
            'id_anggota'        => $data['id_anggota'],
            'id_buku'           => $data['id_buku'],
            'tgl_pinjam'        => $data['tgl_pinjam'],
            'tgl_kembali'       => $data['tgl_kembali'],
            'tgl_return'        => date('Y-m-d')
        );
        //query insert ke tabel 'pengembalian'
        $query = $this->db->insert('pengembalian', $returned);
        if ($query = true) {
            //query delete dengan id
            $delete = $this->m_peminjaman->deletePm($id);
            //notifikasi
            if ($delete = true) {
                $this->session->set_flashdata('info', "Book's returned");
                redirect('peminjaman');
            }
        }
    }
}