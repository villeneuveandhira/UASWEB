<?php

class Publisher extends CI_Controller {

    //memanggil model
    public function __construct() {
        parent::__construct();
        $this->load->model('m_publisher');
    }

    //menampilkan view
    public function index() {
        $isi['data']    = $this->db->get('publisher')->result();
        $this->load->view('publisher/v_publisher', $isi);
    }

    //menambahkan data
    public function add_publisher() {
        $this->load->view('publisher/form_publisher');
    }

    //menyimpan data ke dalam database
    public function save() {
        //isi data
        $data['nama_penerbit']  = $this->input->post('nama_penerbit');
        //query insert ke tabel 'anggota'
        $query = $this->db->insert('publisher', $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data saved successfully');
            redirect('publisher');
        }
    }

    //untuk mengubah data
    public function edit($id) {
        //isi data dari
        $isi['data']    = $this->m_publisher->edit($id);
        $this->load->view('publisher/edit_publisher', $isi);
    }
    
    //untuk memperbaharui data
    public function update() {
        //id
        $id_penerbit           = $this->input->post('id_penerbit');
        //isi data
        $data['nama_penerbit'] = $this->input->post('nama_penerbit');
        //query update(id dan isi data)
        $query = $this->m_publisher->update($id_penerbit, $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data changed successfully');
            redirect('publisher');
        }
    }

    //untuk menghapus data
    public function delete($id) {
        //query delete dengan id
        $query = $this->m_publisher->delete($id);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data deleted successfully');
            redirect('publisher');
        }
    }
}