<?php

class Author extends CI_Controller {

    //memanggil model
    public function __construct() {
        parent::__construct();
        $this->load->model('m_author');
    }

    //menampilkan view
    public function index() {
        //variabel isi dari database
        $isi['data']    = $this->db->get('author')->result();
        $this->load->view('author/v_author', $isi);
    }

    //menambahkan data
    public function add_author() {
        $this->load->view('author/form_author');
    }

    //menyimpan data ke dalam database
    public function save() {
        //isi data
        $data['nama_pengarang'] = $this->input->post('nama_pengarang');
        //query insert ke tabel 'anggota'
        $query = $this->db->insert('author', $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data saved successfully');
            redirect('author');
        }
    }

    //untuk mengubah data
    public function edit($id) {
        $isi['content'] = 'author/edit_author';
        $isi['judul']   = 'Edit Author Data Form';
        //isi data dari
        $isi['data']    = $this->m_author->edit($id);
        $this->load->view('author/edit_author', $isi);
    }

    //untuk memperbaharui data
    public function update() {
        //id
        $id_pengarang           = $this->input->post('id_pengarang');
        //isi data
        $data['nama_pengarang'] = $this->input->post('nama_pengarang');
        //query update(id dan isi data)
        $query = $this->m_author->update($id_pengarang, $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data changed successfully');
            redirect('author');
        }
    }

    //untuk menghapus data
    public function delete($id) {
        //query delete dengan id
        $query = $this->m_author->delete($id);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data deleted successfully');
            redirect('author');
        }
    }
}