<?php

class Anggota extends CI_Controller{

    //memanggil model
    public function __construct() {
        parent::__construct();
        $this->load->model('m_anggota');
    }

    //menampilkan view
    public function index() {
        //variabel isi dari database
        $isi['data']    = $this->db->get('anggota')->result();
        $this->load->view('member/v_anggota', $isi);
    }

    //menambahkan data
    public function add_anggota() {
        $isi['id_anggota']  = $this->m_anggota->id_anggota();
        $this->load->view('member/form_anggota', $isi);
    }

    //menyimpan data ke dalam database
    public function save() {
        //isi data
        $data = array (
            'id_anggota'    => $this->input->post('id_anggota'),
            'nama_anggota'  => $this->input->post('nama_anggota'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'alamat'        => $this->input->post('alamat'),
            'no_hp'         => $this->input->post('no_hp'),
        );
        //query insert ke tabel 'anggota'
        $query = $this->db->insert('anggota', $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data saved successfully');
            redirect('anggota');
        }
    }

    //untuk mengubah data
    public function edit($id) {
        //isi data dari
        $isi['data']  = $this->m_anggota->edit($id);
        $this->load->view('member/edit_anggota', $isi);
    }
    
    //untuk memperbaharui data
    public function update() {
        //id
        $id_anggota = $this->input->post('id_anggota');
        //isi data
        $data = array (
            'id_anggota'    => $this->input->post('id_anggota'),
            'nama_anggota'  => $this->input->post('nama_anggota'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'alamat'        => $this->input->post('alamat'),
            'no_hp'         => $this->input->post('no_hp'),
        );
        //query update(id dan isi data)
        $query = $this->m_anggota->update($id_anggota ,$data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data changed successfully');
            redirect('anggota');
        }
    }

    //untuk menghapus data
    public function delete($id) {
        //query delete dengan id
        $query = $this->m_anggota->delete($id);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data deleted successfully');
            redirect('anggota');
        }
    }
}