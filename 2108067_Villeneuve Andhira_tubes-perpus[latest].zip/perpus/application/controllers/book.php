<?php

class Book extends CI_Controller {

    //memanggil model
    public function __construct() {
        parent::__construct();
        $this->load->model('m_book');
    }

    //menampilkan view
    public function index() {
        $isi['data']    = $this->m_book->get_book_data();
        $this->load->view('book/v_book', $isi);
    }

    //menambahkan data
    public function add_book() {
        // $isi['id_buku']     = $this->m_book->id_book();
        $isi['pengarang']   = $this->db->get('author')->result();
        $isi['penerbit']    = $this->db->get('publisher')->result();
        $this->load->view('book/form_book', $isi);
    }

    //menyimpan data ke dalam database
    public function save() {
        //isi data
        $data = array(
            'id_buku'       => $this->input->post('id_buku'),
            'id_pengarang'  => $this->input->post('id_pengarang'),
            'id_penerbit'   => $this->input->post('id_penerbit'),
            'judul_buku'    => $this->input->post('judul_buku'),
            'tahun_terbit'  => $this->input->post('tahun_terbit'),
            'jumlah'        => $this->input->post('jumlah')
        );
        //query insert ke tabel 'anggota'
        $query = $this->db->insert('book', $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data saved successfully');
            redirect('book');
        }
    }

    //untuk mengubah data
    public function edit($id) {
        //relasi tabel author & publisher (data)
        $isi['pengarang']   = $this->db->get('author')->result();
        $isi['penerbit']    = $this->db->get('publisher')->result();
        //isi data dari
        $isi['data']        = $this->m_book->edit($id);
        $this->load->view('book/edit_book', $isi);
    }

    //untuk memperbaharui data
    public function update() {
        //id
        $id_buku = $this->input->post('id_buku');
        //isi data
        $data = array(
            'id_buku'       => $this->input->post('id_buku'),
            'id_pengarang'  => $this->input->post('id_pengarang'),
            'id_penerbit'   => $this->input->post('id_penerbit'),
            'judul_buku'    => $this->input->post('judul_buku'),
            'tahun_terbit'  => $this->input->post('tahun_terbit'),
            'jumlah'        => $this->input->post('jumlah')
        );
        //query update(id dan isi data)
        $query = $this->m_book->update($id_buku, $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data changed successfully');
            redirect('book');
        }
    }

    //untuk menghapus data
    public function delete($id) {
        //query delete dengan id
        $query = $this->m_book->delete($id);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data deleted successfully');
            redirect('book');
        }
    }
}