<?php

class Login extends CI_Controller{

    //untuk memanggil file model
    public function __construct() {
        parent:: __construct();
        $this->load->model('m_login');
    }

    //untuk memanggil file view
    public function index() {
        $this->load->view('v_login');
    }

    public function proses_login() {
        //menampung input sesuai 'name'
        $user = $this->input->post('username');
        $pass = $this->input->post('password');
        $this->m_login->proses_login($user, $pass);
    }

    public function logout() {
        //hapus sesi saat login
        $this->session->sess_destroy();
        redirect('login');
    }
}