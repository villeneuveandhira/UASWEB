<?php

class Register extends CI_Controller {
    public function index() {
        $this->load->view('v_register');
    }

    //menyimpan data ke dalam database
    public function save() {
        //isi data
        $data = array (
            'nama'      => $this->input->post('nama'),
            'username'  => $this->input->post('username'),
            'password'  => $this->input->post('password'),
            'level'     => $this->input->post('level')
        );
        //query insert ke tabel 'login'
        $query = $this->db->insert('login', $data);
        //notifikasi
        if ($query = true) {
            $this->session->set_flashdata('info', 'Account created!');
            redirect('login');
        }
    }
} 