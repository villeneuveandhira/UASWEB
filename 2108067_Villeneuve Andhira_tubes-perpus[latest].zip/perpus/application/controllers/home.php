<?php

class Home extends CI_Controller{

    public function index() {
        $this->m_squrity->getSqurity();
        //memanggil view
        $this->load->view('v_home');
    }

}