<?php

class Pengembalian extends CI_Controller {

    //load model dan helper
    public function __construct() {
        parent::__construct();
        $this->load->model('m_pengembalian');
        $this->load->helper('tgl_indo_helper');
        $this->load->helper('custom');
        // $this->load->library('pdf_report');
    }
    
    //menampilkan view
    public function index() {
        $isi['data']        = $this->m_pengembalian->getAllData();
        $this->load->view('pengembalian/v_pengembalian', $isi);
    }

    public function export($jenis='pdf') {
        if($jenis=='pdf') {
            $isi['data'] = $this->m_pengembalian->getAllData();
            $html = $this->load->view('pengembalian/laporan_pdf', $isi, TRUE);
            generatePdf($html, 'Laporan Peminjaman', 'A4', 'portrait');
        }
    }
}