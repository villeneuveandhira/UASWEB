<?php

class M_book extends CI_Model{
    //mengambil data join ('author', 'publisher')
    public function get_book_data() {
        $this->db->select('*');
        $this->db->from('book');
        $this->db->join('author', 'book.id_pengarang=author.id_pengarang');
        $this->db->join('publisher', 'book.id_penerbit=publisher.id_penerbit');
        return $this->db->get();
    }

    //direct tabel buku
    public function edit($id) {
        $this->db->select('*');
        $this->db->from('book');
        $this->db->join('author', 'book.id_pengarang=author.id_pengarang');
        $this->db->join('publisher', 'book.id_penerbit=publisher.id_penerbit');
        $this->db->where('book.id_buku', $id);
        return $this->db->get()->row_array();
    }

    //direct update tabel buku
    public function update($id_buku, $data) {
        $this->db->where('id_buku', $id_buku);
        $this->db->update('book', $data);
    }

    //direct delete tabel buku
    public function delete($id) {
        $this->db->where('id_buku', $id);
        $this->db->delete('book');
    }
}