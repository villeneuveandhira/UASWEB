<?php

class M_author extends CI_Model{

    //direct tabel pengarang
    public function edit($id) {
        $this->db->where('id_pengarang', $id);
        return $this->db->get('author')->row_array();
    }

    //direct update tabel pengarang
    public function update($id_pengarang, $data) {
        $this->db->where('id_pengarang', $id_pengarang);
        $this->db->update('author', $data);
    }

    //direct delete tabel pengarang
    public function delete($id) {
        $this->db->where('id_pengarang', $id);
        $this->db->delete('author');
    }
}