<?php

class M_pengembalian extends CI_Model {

    //mengambil data (join, 'anggota' & 'book')
    public function getAllData() {
        $this->db->select('*');
        $this->db->from('pengembalian');
        $this->db->join('anggota', 'pengembalian.id_anggota = anggota.id_anggota');
        $this->db->join('book', 'pengembalian.id_buku = book.id_buku');
        return $this->db->get()->result();
    }
}