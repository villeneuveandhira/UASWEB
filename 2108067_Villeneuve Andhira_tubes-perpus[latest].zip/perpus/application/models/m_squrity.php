<?php

class M_squrity extends CI_Model{

    public function getSqurity() {
        //cek username
        $username = $this->session->userdata('username');
        if (empty($username)) { //jika kosong,
            $this->session->sess_destroy(); //hapus sesi
            redirect('login'); //arahkan kembali ke 'login'
        }
    }
}