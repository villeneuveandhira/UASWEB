<?php

class M_publisher extends CI_Model{

    //direct tabel penerbit
    public function edit($id) {
        $this->db->where('id_penerbit', $id);
        return $this->db->get('publisher')->row_array();
    }

    //direct update tabel penerbit
    public function update($id_penerbit, $data) {
        $this->db->where('id_penerbit', $id_penerbit);
        $this->db->update('publisher', $data);
    }

    //direct delete tabel penerbit
    public function delete($id) {
        $this->db->where('id_penerbit', $id);
        $this->db->delete('publisher');
    }
}