<?php

class M_login extends CI_Model{

    public function proses_login($user, $pass) {
        // $password = md5($pass);
        $user = $this->db->where('username', $user);
        $pass = $this->db->where('password', $pass);
        //cek kemiripan user&pass
        $query = $this->db->get('login');
        if ($query->num_rows()>0) {
            foreach ($query->result()as $row) {
                $sess = array(
                    'id'        => $row->id,
                    'nama'      => $row->nama,
                    'username'  => $row->username,
                    'password'  => $row->password,
                    'level'     => $row->level
                );
                $this->session->set_userdata($sess);
            }
            redirect('home');
        }else {
            $this->session->set_flashdata('info', '<div class="alert alert-danger" role="alert">Please re-check your username or password</div>');
            redirect('login');
        }
    }
}

// 21232f297a57a5a743894a0e4a801fc3
// ff150e31369c0209548717f8e4d0837e