<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Edit Author</title>
</head>
<body>
    <div class="container my-5">
        <form method="post" action="<?= base_url()?>author/update">
            <div class="form-group">
                <label>Author's ID</label>
                <div class="col-sm-10">
                    <input type="text" name="id_pengarang" value="<?= $data['id_pengarang'];?>" class="form-control" readonly>
                </div>
            </div>

            <div class="form-group">
                <label>Author's Name</label>
                <div class="col-sm-10">
                    <input type="text" name="nama_pengarang" value="<?= $data['nama_pengarang'];?>" class="form-control" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?= base_url()?>author" class="btn btn-warning">Cancel</a>
        </form>
    </div>
</body>
</html>