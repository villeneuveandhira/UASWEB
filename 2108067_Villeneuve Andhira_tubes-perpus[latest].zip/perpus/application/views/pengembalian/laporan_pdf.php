<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan</title>
    <style>
        .table {
            width: 100%;
            border-spacing: 0;
        }
        .table tr th,
        .table tr td {
            border: 1px solid #000;
            padding: 4px;
            vertical-align: top;
            text-align: center;
        }
        .logo-report {
            position: absolute;
            width: 60px;
            height: auto;
        }
        span {
            line-height: 1.6;
            font-weight: bold;
        }
        .line {
            border: 0;
            border-style: inset;
            border-top: 1px solid #000;
        }
    </style>
</head>
<body>
    <img src="<?= base_url()?>assets/img/logo1.png" class="logo-report">
    <!-- <h1>Laporan Peminjaman</h1> -->
    <table style="width: 100%;">
        <tr>
            <td align="center">
                <span>
                    LOVEBOOK<br>E-LIBRARY
                </span>
            </td>
        </tr>
    </table>

    <hr class="line">
    <p align="center">
        LAPORAN PEMINJAMAN BUKU
    </p>

    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama_Peminjam</th>
                <th>Judul_Buku</th>
                <th>Tanggal_transaksi</th>
                <th>Tanggal_tenggat-waktu</th>
                <th>Tanggal_dikembalikan</th>
            </tr>
        </thead>
        <tbody>
            <?php
                foreach ($data as $row) {?>
                    <tr>
                        <td><?= $row->id_pengembalian;?></td>
                        <td><?= $row->nama_anggota;?></td>
                        <td><?= $row->judul_buku;?></td>
                        <td><?= mediumdate_indo($row->tgl_pinjam);?></td>
                        <td><?= mediumdate_indo($row->tgl_kembali);?></td>
                        <td><?= mediumdate_indo($row->tgl_return);?></td>
                    </tr>
                <?php }
            ?>
        </tbody>
    </table>
</body>
</html>
