<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url()?>assets/style.css">
    <title>Report</title>
    <style>
        .box-header {
            margin-left: 150px;
            padding: 35px 0;
            align-items: center;
        }
    </style> 
</head>
<body>
    <div class="option">
        <div class="action">
            <div class="profile" onclick="menuToggle();">
                <img src="<?= base_url()?>assets/img/user.png">
            </div>
            <div class="menu">
                <h3>
                    <?php
                        $nama = $this->session->userdata('nama');
                        $firstname = explode(' ', $nama);
                        echo $name = $firstname['0'];
                    ?>
                </h3>
                <h2>
                    <?php
                        $level = $this->session->userdata('level');
                        echo $level;
                    ?>
                </h2><br>
                <ul>
                    <li><img src="<?= base_url()?>assets/img/log-out.png"><a href="<?= base_url()?>login/logout">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="backimg">
        <div class="navbar">
            <img src="<?= base_url()?>assets/img/logo1.png" class="logo">
            <ul>
                <li><a href="<?= base_url()?>home">Home</a></li>
                <li><a href="<?= base_url()?>anggota">Member</a></li>
                <li><a href="<?= base_url()?>author">Author</a></li>
                <li><a href="<?= base_url()?>publisher">Publiser</a></li>
                <li><a href="<?= base_url()?>book">Book</a></li>
            </ul>
        </div>
        <div class="box-header">  
            <div class="col-md-2">
                <a href="<?= base_url()?>pengembalian/export" class="btn btn-danger btn-block btn-pdf" target="_blank"><i class="fa fa-file-pdf-o"></i>Export PDF</a>
            </div>
        </div>
        <div class="container">
            <table class="table table-striped table-dark">
                <thead>
                    <tr>
                        <th>Id(s)</th>
                        <th>Member's Name(s)</th>
                        <th>Title(s)</th>
                        <th>Borrow Date(s)</th>
                        <th>Return date(s)</th>
                        <th>Returned</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        foreach ($data as $row) {?>
                            <tr>
                                <td><?= $row->id_pengembalian;?></td>
                                <td><?= $row->nama_anggota;?></td>
                                <td><?= $row->judul_buku;?></td>
                                <td><?= mediumdate_indo($row->tgl_pinjam);?></td>
                                <td><?= mediumdate_indo($row->tgl_kembali);?></td>
                                <td><?= mediumdate_indo($row->tgl_return);?></td>
                            </tr>
                        <?php }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function menuToggle() {
            const toggleMenu = document.querySelector('.menu');
            toggleMenu.classList.toggle('active');
        }
    </script>
</body>
</html>