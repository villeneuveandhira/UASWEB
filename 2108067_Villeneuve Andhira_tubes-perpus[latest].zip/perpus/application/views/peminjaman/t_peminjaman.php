<?php
    $tgl_pinjam     = date('Y-m-d');
    $weeks          = mktime(0,0,0,date("n"), date("j") + 7, date("Y"));
    $tgl_kembali    = date('Y-m-d', $weeks);
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <script>
        //id (buku), fungsinya:
        $('#id_buku').change(function(){
            //variabel
            var id = $(this).val();
            //ajax (asynchronous javascript and XML)
            $.ajax({
                //link
                url : '<?= base_url()?>peminjaman/jumlah_buku',
                //data
                data : {id:id},
                //metode
                method : 'post',
                dataType : 'json',
                //hasil
                success:function(hasil){
                    //mengubah variabel menjadi string
                    var jumlah = JSON.stringify(hasil.jumlah);
                    //batasan (spli, utk memisahkan. join, utk batas maks 1x)
                    var jumlah1 = jumlah.split('"').join('');
                    //jika stok habis atau kurang dari '0'
                    if (jumlah1 <= 0) {
                        alert('Sorry, this book is out of stock');
                        location.reload();
                    }
                }
            })
        });
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Form Transaction</title>
</head>
<body>
    <div class="container my-5">
        <form method="post" action="<?= base_url()?>peminjaman/save">
            <div class="form-group">
                <label>ID (Borrow Book)</label>
                <div class="col-sm-10">
                    <input type="text" name="id_pm" value="<?= $id_peminjaman;?>" class="form-control" readonly>
                </div>
            </div>

            <div class="form-group">
                <label>Name(s) 'Borrower'</label>
                <div class="col-sm-10">
                    <select name="id_anggota" class="form-control">
                        <option value=""> - Choose Member - </option>
                        <?php
                            foreach ($peminjam as $row) {?>
                                <option value="<?= $row->id_anggota;?>"><?= $row->nama_anggota;?></option>
                            <?php }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Book(s)</label>
                <div class="col-sm-10">
                    <select name="id_buku" id="id_buku" class="form-control">
                        <option value=""> - Choose Book - </option>
                        <?php
                            foreach ($book as $row) {?>
                                <option value="<?= $row->id_buku;?>"><?= $row->judul_buku;?></option>
                            <?php }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Borrow's date</label>
                <div class="col-sm-10">
                    <input type="date" name="tgl_pinjam" value="<?= $tgl_pinjam?>" class="form-control" readonly>
                </div>
            </div>

            <div class="form-group">
                <label>Return's date</label>
                <div class="col-sm-10">
                    <input type="date" name="tgl_kembali" value="<?= $tgl_kembali?>" class="form-control" readonly>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Borrow</button>
            <a href="<?= base_url()?>peminjaman" class="btn btn-warning">Cancel</a>
        </form>
    </div>
</body>
</html>