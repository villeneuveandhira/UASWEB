<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Edit Member</title>
</head>
<body>
    <div class="container my-5">
        <form method="post" action="<?= base_url()?>anggota/update">
            <div class="form-group">
                <label>ID (Lovebook Member)</label>
                <div class="col-sm-10">
                <input type="text" name="id_anggota" value="<?= $data['id_anggota'];?>" class="form-control" readonly>
                </div>
            </div>

            <div class="form-group">
                <label>Name</label>
                <div class="col-sm-10">
                    <input type="text" name="nama_anggota" value="<?= $data['nama_anggota'];?>" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label>Jenis Kelamin</label>
                <div class="col-sm-10">
                    <select name="jenis_kelamin" class="form-control" required>
                        <?php
                            if ($data['jenis_kelamin'] == "Laki-laki") {?>
                                <option value="Laki-laki" selected> - Male - </option>
                                <option value="Perempuan"> - Female - </option>
                            <?php } else { ?>
                                <option value="Laki-laki"> - Male - </option>
                                <option value="Perempuan" selected> - Female - </option>
                            <?php }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <div class="col-sm-10">
                    <textarea name="alamat" class="form-control" cols="30" rows="5" required><?= $data['alamat'];?></textarea>
                </div>
            </div>

            <div class="form-group">
                <label>Phone Number</label>
                <div class="col-sm-10">
                    <input type="text" name="no_hp" value="<?= $data['no_hp'];?>" class="form-control" required>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?= base_url()?>anggota" class="btn btn-warning">Cancel</a>
        </form>
    </div>
</body>
</html>