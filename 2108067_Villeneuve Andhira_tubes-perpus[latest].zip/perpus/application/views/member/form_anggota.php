<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Form Member</title>
</head>
<body>
    <div class="container my-5">
        <form method="post" action="<?= base_url()?>anggota/save">
            <div class="form-group">
                <label>ID (Lovebook Member)</label>
                <div class="col-sm-10">
                    <input type="text" name="id_anggota" value="<?= $id_anggota?>" class="form-control" readonly>
                </div>
            </div>
            
            <div class="form-group">
                <label>Name</label>
                <div class="col-sm-10">
                    <input type="text" name="nama_anggota" class="form-control" placeholder="Enter member's name" required>
                </div>
            </div>
            
            <div class="form-group">
                <label>Jenis Kelamin</label>
                <div class="col-sm-10">
                    <select name="jenis_kelamin" class="form-control" required>
                        <option value=""> - Select your gender - </option>
                        <option value="Laki-laki"> - Male - </option>
                        <option value="Perempuan"> - Female - </option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label>Alamat</label>
                <div class="col-sm-10">
                    <textarea name="alamat" class="form-control" cols="30" rows="5" required></textarea>
                </div>
            </div>
            
            <div class="form-group">
                <label>Phone Number</label>
                <div class="col-sm-10">
                    <input type="text" name="no_hp" class="form-control" placeholder="Enter phone number" required>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= base_url()?>anggota" class="btn btn-warning">Cancel</a>
        </form>
    </div>
</body>
</html>