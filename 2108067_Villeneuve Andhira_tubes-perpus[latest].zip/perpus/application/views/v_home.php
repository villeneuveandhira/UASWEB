<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=logo1.0">
    <title>Home</title>
    <link rel="stylesheet" href="<?= base_url()?>assets/style.css">
</head>
<body>
    <!-- Navbar -->
        <!-- Profile -->
            <div class="option">
                <div class="action">
                    <div class="profile" onclick="menuToggle();">
                        <img src="<?= base_url()?>assets/img/user.png">
                    </div>
                    <div class="menu">
                        <h3>
                            <?php
                                $nama = $this->session->userdata('nama');
                                $firstname = explode(' ', $nama);
                                echo $name = $firstname['0'];
                            ?>
                        </h3>
                        <h2>
                            <?php
                                $level = $this->session->userdata('level');
                                echo $level;
                            ?>
                        </h2><br>
                        <ul>
                            <li><img src="<?= base_url()?>assets/img/log-out.png"><a href="<?= base_url()?>login/logout">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        <!-- end of Profile -->
        <!-- Menu -->
            <div class="banner">
                <div class="navbar">
                    <img src="<?= base_url()?>assets/img/logo1.png" class="logo">
                    <ul>
                        <li><a href="<?= base_url()?>home">Home</a></li>
                        <li><a href="<?= base_url()?>anggota">Member</a></li>
                        <li><a href="<?= base_url()?>author">Author</a></li>
                        <li><a href="<?= base_url()?>publisher">Publiser</a></li>
                        <li><a href="<?= base_url()?>book">Book</a></li>
                    </ul>
                </div>
            </div>
        <!-- end of Menu -->
    <!-- end of Navbar -->

    <!-- Content -->
    <div class="content">
        <h1>WELCOME TO LOVEBOOK E-LIBRARY</h1>
        <p>This is a web-based library online application with<br>a variety of data and features provided for users <br>and provides a book borrowing system.</p>       
        <div>
            <button type="button"><span></span><a href="<?= base_url()?>peminjaman">TRANSACTION</a></button>
            <?php
                if ($this->session->userdata('level') == 'Administrator') {?>
                    <button type="button"><span></span><a href="<?= base_url()?>pengembalian">REPORT</a></button>
                <?php }
            ?>
        </div>
    </div>
    <!-- end of Content -->

    <script>
        function menuToggle() {
            const toggleMenu = document.querySelector('.menu');
            toggleMenu.classList.toggle('active');
        }
    </script>
</body>
</html>