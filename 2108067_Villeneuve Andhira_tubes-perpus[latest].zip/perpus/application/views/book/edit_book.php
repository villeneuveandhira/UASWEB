<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Edit Book</title>
</head>
<body>
    <div class="container my-5">
        <form method="post" action="<?= base_url()?>book/update">
            <div class="form-group">
                <label>ID (Book's Code)</label>
                <div class="col-sm-10">
                    <input type="text" name="id_buku" value="<?= $data['id_buku'];?>" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label>Title</label>
                <div class="col-sm-10">
                    <input type="text" name="judul_buku" value="<?= $data['judul_buku'];?>" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label>Author</label>
                <div class="col-sm-10">
                    <select name="id_pengarang" class="form-control select2" required>
                        <option value=""> - Choose Author - </option>
                            <?php
                                foreach ($pengarang as $row) {
                                    if ($data['id_pengarang'] == $row->id_pengarang) {?>
                                        <option value="<?= $row->id_pengarang;?>" selected><?= $row->nama_pengarang;?></option>
                                <?php } else {?>
                                        <option value="<?= $row->id_pengarang;?>"><?= $row->nama_pengarang;?></option>
                                <?php }
                                }
                            ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Publisher</label>
                <div class="col-sm-10">
                    <select name="id_penerbit" class="form-control select2" required>
                        <option value=""> - Choose Publisher - </option>
                            <?php
                                foreach ($penerbit as $row) {
                                    if ($data['id_pengarang'] == $row->id_penerbit) {?>
                                        <option value="<?= $row->id_penerbit;?>" selected><?= $row->nama_penerbit;?></option>
                                <?php } else {?>
                                        <option value="<?= $row->id_penerbit;?>"><?= $row->nama_penerbit;?></option>
                                <?php }
                                }
                            ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Publication date</label>
                <div class="col-sm-10">
                    <select name="tahun_terbit" class="form-control select2" required>
                        <option value=""> - Choose Year - </option>
                        <?php
                            for ($tahun = 1945; $tahun<=2020; $tahun++) {
                                if ($data['tahun_terbit'] == $tahun) {?>
                                    <option value="<?= $tahun;?>" selected><?= $tahun;?></option>
                                <?php } else {?>
                                        <option value="<?= $tahun;?>"><?= $tahun;?></option>
                                <?php }
                            }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Total</label>
                <div class="col-sm-10">
                    <input type="number" name="jumlah" value="<?= $data['jumlah'];?>" class="form-control" required>
                </div>
            </div>

            <div class="box-footer">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?= base_url()?>book" class="btn btn-warning">Cancel</a>
        </form>
    </div>
</body>
</html>