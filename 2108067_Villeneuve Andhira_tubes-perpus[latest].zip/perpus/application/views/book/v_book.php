
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url()?>assets/style.css">
    <title>Book</title>
</head>
<body>
    <div class="option">
        <div class="action">
            <div class="profile" onclick="menuToggle();">
                <img src="<?= base_url()?>assets/img/user.png">
            </div>
            <div class="menu">
                <h3>
                    <?php
                        $nama = $this->session->userdata('nama');
                        $firstname = explode(' ', $nama);
                        echo $name = $firstname['0'];
                        ?>
                </h3>
                <h2>
                    <?php
                        $level = $this->session->userdata('level');
                        echo $level;
                        ?>
                </h2><br>
                <ul>
                    <li><img src="<?= base_url()?>assets/img/log-out.png"><a href="<?= base_url()?>login/logout">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="backimg">
        <div class="navbar">
            <img src="<?= base_url()?>assets/img/logo1.png" class="logo">
            <ul>
                <li><a href="<?= base_url()?>home">Home</a></li>
                <li><a href="<?= base_url()?>anggota">Member</a></li>
                <li><a href="<?= base_url()?>author">Author</a></li>
                <li><a href="<?= base_url()?>publisher">Publiser</a></li>
                <li><a href="<?= base_url()?>book">Book</a></li>
            </ul>
        </div>
        <!-- Content -->
            <!-- Alert Message -->
                <?php
                    if (!empty($this->session->flashdata('info'))) {?>
                <div class="alert alert-success" role="alert"><?= $this->session->flashdata('info');?></div>
                <?php }
                ?>
            <!-- end of Alert Message -->
            <!-- Data Table -->
                <div class="container">
                    <button class="btn btn-primary my-5"><a href="<?= base_url()?>book/add_book" class="text-light">Add book</a></button>

                    <table class="table table-striped table-dark">
                        <thead>
                            <tr>
                                <th>Id(s)</th>
                                <th>Title(s)</th>
                                <th>Author(s)</th>
                                <th>Publisher(s)</th>
                                <th>Publication date(s)</th>
                                <th>Total(s)</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                foreach ($data->result() as $row) {?>
                                    <tr>
                                        <td><?= $row->id_buku;?></td>
                                        <td><?= $row->judul_buku;?></td>
                                        <td><?= $row->nama_pengarang;?></td>
                                        <td><?= $row->nama_penerbit;?></td>
                                        <td><?= $row->tahun_terbit;?></td>
                                        <td><?= $row->jumlah;?></td>
                                        <td>
                                            <a href="<?= base_url()?>book/edit/<?= $row->id_buku;?>" class="btn btn-success btn-xs"> Edit</a>
                                            <a href="<?= base_url()?>book/delete/<?= $row->id_buku;?>" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure want to delete?')"> Delete</a>
                                        </td>
                                    </tr>    
                                <?php }
                        ?>
                        </tbody>
                    </table>
                </div>
            <!-- end of Data Table -->
        <!-- end of Content -->
    </div>

    <script>
        function menuToggle() {
            const toggleMenu = document.querySelector('.menu');
            toggleMenu.classList.toggle('active');
        }
    </script>
</body>
</html>